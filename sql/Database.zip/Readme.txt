Fresh Database Queries 
WOOT!